Samia Parvin Ananna - Portfolio Website (offline copy)

Open index.html in any web browser (double-click) to view the full portfolio offline.
Samia_Parvin_Ananna_CV.pdf is the downloadable CV.
